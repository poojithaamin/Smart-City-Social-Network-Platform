<html>
<body>    
<h3>Please enter your issue</h3>
<form action="/action.php" method="post">
<textarea rows="4" cols="50" name="comment"></textarea></br>
<input type="submit" name="SubmitButton"/>
</form>    
</body>
</html>




