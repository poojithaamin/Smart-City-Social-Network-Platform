<html>
<body>    
<form action="/new.php" method="post">
  <h3>Click to view dahsboard</h3>
  <input type="submit" name="SubmitButton"/>
</form>    
</body>
</html>




